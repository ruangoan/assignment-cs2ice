import { Rankdata } from './rankdata';

describe('Rankdata', () => {
  it('should create an instance', () => {
    expect(new Rankdata()).toBeTruthy();
  });
});
