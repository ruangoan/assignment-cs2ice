import { Tip } from './tip';

describe('Tip', () => {
  it('should create an instance', () => {
    expect(new Tip()).toBeTruthy();
  });
});
