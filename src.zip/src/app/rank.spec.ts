import { Rank } from './rank';

describe('Rank', () => {
  it('should create an instance', () => {
    expect(new Rank()).toBeTruthy();
  });
});
